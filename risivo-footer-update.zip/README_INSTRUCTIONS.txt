# 📦 EXTRACT & DEPLOY INSTRUCTIONS

## 🎯 QUICK STEPS (5 minutes)

### Step 1: Download the ZIP file
- Download `risivo-footer-update.zip` from this conversation
- Save it to: `C:\Users\Buzgrowth\Documents\`

### Step 2: Extract & Overwrite
```bash
# Navigate to your project folder
cd C:\Users\Buzgrowth\Documents\risivo-website

# Extract the ZIP (this will overwrite existing files in src/)
# Use Windows Explorer: Right-click risivo-footer-update.zip → Extract Here
# OR use command line:
tar -xf ..\risivo-footer-update.zip
```

### Step 3: Verify Files Updated
Check that these files exist:
- ✅ `src/pages/homepage-step6.ts` (updated)
- ✅ `src/pages/features.ts` (NEW)
- ✅ `src/pages/pricing.ts` (NEW)
- ✅ `src/index.tsx` (updated)
- ✅ `src/layouts/BaseLayout.ts` (updated)
- ✅ `src/components/Footer.ts` (updated with new footer)
- ✅ `src/data/navigation.ts` (updated with SVG icons)

### Step 4: Deploy
```bash
cd C:\Users\Buzgrowth\Documents\risivo-website

git add -A

git commit -m "feat: Apply new footer to all pages (homepage, features, pricing, contact)"

git push origin staging

npm run build

npx wrangler pages deploy dist --project-name risivo-staging --branch staging --commit-dirty=true
```

---

## 📋 WHAT'S INCLUDED IN THE ZIP

```
src/
├── pages/
│   ├── homepage-step6.ts    ✅ Updated (uses BaseLayout with new footer)
│   ├── features.ts           ✅ NEW (Features page with footer)
│   └── pricing.ts            ✅ NEW (Pricing page with footer)
├── layouts/
│   └── BaseLayout.ts         ✅ Updated (copyright fixed)
├── components/
│   └── Footer.ts             ✅ Updated (new footer design)
├── data/
│   └── navigation.ts         ✅ Updated (SVG social icons)
└── index.tsx                 ✅ Updated (routes for features/pricing)
```

---

## ✅ VERIFICATION AFTER DEPLOYMENT

Visit in Incognito mode:
1. https://risivo-staging.pages.dev/ (Homepage with new footer)
2. https://risivo-staging.pages.dev/features (NEW page with footer)
3. https://risivo-staging.pages.dev/pricing (NEW page with footer)
4. https://risivo-staging.pages.dev/contact (Footer already working)

Check each page for:
- ✅ Newsletter section at top
- ✅ White Risivo logo visible
- ✅ 90px language selector (EN, ES, FR, DE)
- ✅ 4 menu columns
- ✅ Social media icons at bottom
- ✅ Copyright: "© 2025 Velocity Automation Corp. All rights reserved."

---

## 🔄 FOR FUTURE UPDATES

**Every time I make changes:**
1. I'll create a new ZIP with updated files
2. You download and extract to your project folder
3. You run the 4 deploy commands
4. Changes go live in 5 minutes

**This workflow will be our standard process going forward!**

---

## ⏱️ TIME ESTIMATE

- Download ZIP: 10 seconds
- Extract files: 10 seconds  
- Run deploy commands: 3 minutes
- Verify on staging: 1 minute
**Total: ~5 minutes**

---

## 🆘 TROUBLESHOOTING

### Issue: "File already exists"
**Solution**: That's fine! The extraction will overwrite the files.

### Issue: Git shows many changed files
**Solution**: Normal! The ZIP contains the entire src/ folder. Git will only commit what changed.

### Issue: Build fails
**Solution**: 
```bash
npm install  # Reinstall dependencies
npm run build  # Try again
```

### Issue: Deploy fails
**Solution**:
```bash
npx wrangler pages deploy dist --project-name risivo-staging --branch staging --commit-dirty=true
```

---

## ✅ READY TO EXTRACT AND DEPLOY!

1. Download `risivo-footer-update.zip`
2. Extract to `C:\Users\Buzgrowth\Documents\risivo-website`
3. Run the 4 deploy commands
4. Verify on staging site

**Let me know when you're ready and I'll provide the download link!**
