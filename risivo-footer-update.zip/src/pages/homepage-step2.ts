/**
 * STEP 2: Basic + PartnerLogos + SimplifiedFeatures
 */

import { globalStyles } from '../styles/global.css.ts';
import { Navigation } from '../components/Navigation';
import { PartnerLogos } from '../components/PartnerLogos';
import { SimplifiedFeatures } from '../components/SimplifiedFeatures';
import { designSystem } from '../styles/design-system';

const { colors, spacing } = designSystem;

const navigationItems = [
  { label: 'Features', href: '/features' },
  { label: 'Pricing', href: '/pricing' },
  { label: 'About', href: '/about' }
];

export const HomepageStep2 = () => {
  const currentYear = new Date().getFullYear();
  
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Risivo</title>
      <link rel="icon" type="image/png" href="/favicon.png">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Jost:wght@400;500;600;700&display=swap" rel="stylesheet">
      <style>${globalStyles}</style>
    </head>
    <body>
      ${Navigation({
        logoSrc: '/risivo-logo.png',
        items: navigationItems,
        ctaText: 'Start Free Trial',
        ctaHref: 'https://app.risivo.com/signup'
      })}

      <main style="padding-top: 100px;">
        <!-- Hero -->
        <section style="
          background: linear-gradient(135deg, #683FE9 0%, #7C3AED 100%);
          padding: 120px 20px;
          text-align: center;
          color: white;
        ">
          <h1 style="font-size: 3.5rem; font-weight: 700; margin-bottom: 20px; font-family: 'Jost', sans-serif;">
            Powerful Marketing Meets<br/>Seamless Design
          </h1>
          <p style="font-size: 1.25rem; margin-bottom: 40px; opacity: 0.9;">
            Transform how you manage customer relationships with intelligent automation
          </p>
          <a href="https://app.risivo.com/signup" style="
            background: white;
            color: #683FE9;
            padding: 16px 40px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1.125rem;
            display: inline-block;
          ">Start Free Trial</a>
        </section>

        ${PartnerLogos()}
        
        ${SimplifiedFeatures()}

        <!-- CTA -->
        <section style="
          background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
          padding: 80px 20px;
          text-align: center;
          color: white;
        ">
          <h2 style="font-size: 2.5rem; font-weight: 700; margin-bottom: 20px; font-family: 'Jost', sans-serif;">
            Ready to Get Started?
          </h2>
          <p style="font-size: 1.125rem; margin-bottom: 40px; opacity: 0.9;">
            Join 50,000+ businesses using Risivo
          </p>
          <a href="https://app.risivo.com/signup" style="
            background: #683FE9;
            color: white;
            padding: 16px 40px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1.125rem;
            display: inline-block;
          ">Start Free Trial</a>
        </section>
      </main>
      
      <footer style="background: #1f2937; color: white; padding: 60px 20px 30px;">
        <div style="max-width: 1200px; margin: 0 auto;">
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 40px; margin-bottom: 40px;">
            <div>
              <h4 style="font-weight: 600; margin-bottom: 15px;">Risivo</h4>
              <p style="color: #9ca3af; font-size: 0.875rem;">Intelligent CRM that accelerates growth</p>
            </div>
            <div>
              <h4 style="font-weight: 600; margin-bottom: 15px;">Product</h4>
              <ul style="list-style: none; padding: 0;">
                <li style="margin-bottom: 10px;"><a href="/features" style="color: #9ca3af; text-decoration: none;">Features</a></li>
                <li style="margin-bottom: 10px;"><a href="/pricing" style="color: #9ca3af; text-decoration: none;">Pricing</a></li>
              </ul>
            </div>
            <div>
              <h4 style="font-weight: 600; margin-bottom: 15px;">Company</h4>
              <ul style="list-style: none; padding: 0;">
                <li style="margin-bottom: 10px;"><a href="/about" style="color: #9ca3af; text-decoration: none;">About</a></li>
                <li style="margin-bottom: 10px;"><a href="/contact" style="color: #9ca3af; text-decoration: none;">Contact</a></li>
              </ul>
            </div>
          </div>
          <div style="border-top: 1px solid rgba(255,255,255,0.1); padding-top: 20px; text-align: center;">
            <p style="color: #9ca3af; font-size: 0.875rem;">© ${currentYear} Risivo. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </body>
    </html>
  `;
};
