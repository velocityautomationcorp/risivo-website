/**
 * MINIMAL TEST PAGE
 * To isolate the Internal Server Error
 */

export const HomepageTest = () => {
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Risivo Test</title>
    </head>
    <body>
      <h1>Test Page - If you see this, the basic setup works!</h1>
      <p>This is a minimal test page.</p>
    </body>
    </html>
  `;
};
